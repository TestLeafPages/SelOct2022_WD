package steps;

import io.cucumber.java.en.And;

public class ViewLeadsPage extends BaseClass {
	

	@And("Verify ViewLeads Page")
	public void verifyViewLeadsPage() {
		System.out.println("Verified CreateLead successfully");
	}

	
	

}
